﻿using Tekla.Structures.Plugins;

namespace $safeprojectname$
{
    public class PluginData
    {
        // Plugin data fields here:
        [StructuresField("beamClass")]
        public string beamClass;
    }
}
